"""
Agent 8: Gemini Multimodal

Advanced multimodal agent that analyzes both text and visual elements in PDFs.
Explicitly instructed to consider charts, tables, layouts, and visual relationships.
"""

from google.adk import Agent
from shared.settings import DEFAULT_MODEL
from shared.prompts import MULTIMODAL_PROMPT


def create_agent() -> Agent:
    """
    Create the Gemini Multimodal agent.
    
    This agent is similar to Agent 2 (PDF Part) but with explicit
    instructions to analyze visual elements, not just text.
    
    It considers:
    - Text content and meaning
    - Charts and graphs
    - Tables and structured data
    - Document layout and structure
    - Visual relationships between elements
    
    This is the most sophisticated single-pass PDF understanding agent,
    leveraging Gemini's multimodal capabilities to the fullest.
    
    Use cases:
    - Documents with important visual elements
    - Financial reports with charts
    - Scientific papers with figures
    - Presentations
    - Any document where layout matters
    
    Returns:
        Configured Agent instance for multimodal PDF analysis
    """
    return Agent(
        name="gemini_multimodal",
        model=DEFAULT_MODEL,  # Uses Gemini's multimodal capabilities
        instruction=MULTIMODAL_PROMPT
    )


# For direct testing
if __name__ == "__main__":
    import asyncio
    from google.adk import Runner
    from google.adk.services import InMemorySessionService
    
    async def test():
        agent = create_agent()
        runner = Runner(
            app_name="pdf_qa",
            root_agent=agent,
            session_service=InMemorySessionService()
        )
        
        test_question = "Describe the key charts and their insights from the document"
        print(f"\nQuestion: {test_question}\n")
        print("="*60)
        print("\nNOTE: This agent expects a PDF with visual elements.")
        print("It will analyze both text and visual content.\n")
        
        async for event in runner.run_async(
            user_id="test",
            session_id="test_multimodal",
            new_message=test_question
        ):
            if event.author == "gemini_multimodal" and not event.partial:
                print(f"\n{event.content.parts[0].text}\n")
                print("="*60)
    
    asyncio.run(test())
