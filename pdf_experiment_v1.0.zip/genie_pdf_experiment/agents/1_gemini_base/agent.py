"""
Agent 1: Gemini Base

The simplest baseline - pure LLM with no PDF access.
Relies entirely on training knowledge.
"""

from google.adk import Agent
from shared.settings import DEFAULT_MODEL
from shared.prompts import BASE_SYSTEM_PROMPT


def create_agent() -> Agent:
    """
    Create the Gemini Base agent.
    
    This agent receives only the user's question and must answer
    based on its training knowledge alone. No PDF access.
    
    Returns:
        Configured Agent instance
    """
    return Agent(
        name="gemini_base",
        model=DEFAULT_MODEL,
        instruction=BASE_SYSTEM_PROMPT + """

Note: You do not have access to any specific documents. Answer based on
your general knowledge and training."""
    )


# For direct testing
if __name__ == "__main__":
    import asyncio
    from google.adk import Runner
    from google.adk.services import InMemorySessionService
    
    async def test():
        agent = create_agent()
        runner = Runner(
            app_name="pdf_qa",
            root_agent=agent,
            session_service=InMemorySessionService()
        )
        
        test_question = "What is machine learning?"
        print(f"\nQuestion: {test_question}\n")
        print("="*60)
        
        async for event in runner.run_async(
            user_id="test",
            session_id="test_gemini_base",
            new_message=test_question
        ):
            if event.author == "gemini_base" and not event.partial:
                print(f"\n{event.content.parts[0].text}\n")
                print("="*60)
    
    asyncio.run(test())
