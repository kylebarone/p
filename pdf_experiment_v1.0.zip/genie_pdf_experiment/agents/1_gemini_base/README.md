# Agent 1: Gemini Base

## Description

The simplest baseline agent - a pure LLM with no document access. This agent answers questions using only its training knowledge.

## Purpose

Serves as a **baseline** to compare against more sophisticated approaches. Shows what's possible with just the model's training data, without any external tools or document retrieval.

## Architecture

- **Model**: gemini-2.0-flash-exp
- **Tools**: None
- **PDF Access**: None
- **Complexity**: Minimal

## How It Works

1. Receives user question
2. Generates response based on training knowledge
3. Returns answer

That's it! No PDF processing, no search, no tools.

## When to Use

- Questions about general knowledge
- Concepts and definitions
- Situations where documents aren't needed
- As a baseline for comparison

## When NOT to Use

- Questions requiring specific document information
- Queries about proprietary or recent data
- Tasks needing precise citations

## Example Usage

```python
from agents.agent_1_gemini_base.agent import create_agent
from google.adk import Runner
from google.adk.services import InMemorySessionService

agent = create_agent()
runner = Runner(
    app_name="pdf_qa",
    root_agent=agent,
    session_service=InMemorySessionService()
)

# Ask a general question
async for event in runner.run_async(
    user_id="user1",
    session_id="session1",
    new_message="What is machine learning?"
):
    if event.author == "gemini_base" and not event.partial:
        print(event.content.parts[0].text)
```

## Testing

```bash
# Run the agent directly
python agents/1_gemini_base/agent.py

# Or use the CLI
python run_agent.py 1 "What is artificial intelligence?"
```

## Limitations

- Cannot access specific documents
- May hallucinate details about unfamiliar topics
- Cannot provide document-specific citations
- Limited to training data cutoff

## Comparison Notes

This agent establishes the baseline performance. All other agents (2-8) add various capabilities on top of this foundation:

- Agents 2-3: Add PDF access
- Agents 4-5: Add search and retrieval
- Agents 6-8: Add external tools and orchestration
