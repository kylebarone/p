# Agent 3: Gemini PDF Processed

## Description

This agent preprocesses PDFs by extracting text and including it in the prompt. This gives more control over how the document is presented to the model.

## Purpose

Demonstrates the **preprocessing pipeline** approach - explicit text extraction and formatting before sending to the LLM.

## Architecture

- **Model**: gemini-2.0-flash-exp
- **Tools**: None (uses PDF tools internally)
- **PDF Access**: Preprocessed text extraction
- **Processing**: extract_text_from_pdf() at initialization
- **Complexity**: Low-Medium

## How It Works

1. At agent creation, extract all text from PDF
2. When user asks question, create prompt with:
   - System instruction
   - Full PDF text
   - User question
3. Send combined prompt to LLM
4. Return answer

This is a **Custom Agent** that wraps an LLM agent with preprocessing logic.

## Advantages

✅ Full control over text extraction  
✅ Can clean/format text before prompting  
✅ Deterministic - same text every time  
✅ Can apply chunking strategies  
✅ Works with any PDF processing library  

## Disadvantages

❌ Still limited by context window  
❌ Entire document in every request  
❌ Preprocessing overhead at startup  
❌ Less efficient for large documents  

## When to Use

- Medium-sized PDFs (10-100 pages)
- When you need to clean/normalize text
- When you want explicit control over extraction
- Single or few-turn conversations

## Example Usage

```python
from agents.agent_3_gemini_pdf_processed.agent import create_agent

# Create agent with specific PDF
agent = create_agent(pdf_path="data/pdfs/finance_report.pdf")

runner = Runner(
    app_name="pdf_qa",
    root_agent=agent,
    session_service=InMemorySessionService()
)

async for event in runner.run_async(
    user_id="user1",
    session_id="session1",
    new_message="What was the Q3 revenue?"
):
    if event.author == "gemini_pdf_processed" and not event.partial:
        print(event.content.parts[0].text)
```

## Code Structure

```python
class GeminiPdfProcessedAgent(BaseAgent):
    def __init__(self, pdf_path):
        # Extract PDF text at initialization
        self.pdf_text = extract_text_from_pdf(pdf_path)
    
    async def _run_async_impl(self, ctx):
        # Get user question
        user_message = ctx.session.events[-1].content
        
        # Create prompt with PDF text + question
        full_instruction = f"""
        Document: {self.pdf_text}
        Question: {user_message}
        """
        
        # Use LLM agent to answer
        llm_agent = Agent(instruction=full_instruction)
        async for event in llm_agent.run_async(ctx):
            yield event
```

## Testing

```bash
# Run the agent directly
python agents/3_gemini_pdf_processed/agent.py

# Or use the CLI
python run_agent.py 3 "Summarize the key findings"
```

## Implementation Notes

- Uses Custom Agent pattern (inherits from BaseAgent)
- Text extraction happens once at initialization
- Could be extended to:
  - Apply chunking strategies
  - Clean/normalize text
  - Extract specific sections
  - Add metadata

## Future Enhancements

- Smart chunking when document exceeds context window
- Text cleaning and normalization
- Table extraction and formatting
- Section-based extraction

## Comparison to Other Agents

vs Agent 2 (Multimodal): More control, explicit extraction  
vs Agent 4 (RAG): Still includes full text, not selective  
vs Agent 5 (Agent Search): Simpler, no search capability  
vs Agent 6-8 (MCP): Direct control vs external tools  
