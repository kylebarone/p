"""
Agent 3: Gemini PDF Processed

LLM with preprocessed PDF text included in the prompt.
Text is extracted and optionally chunked before being sent to the model.
"""

from google.adk import Agent
from google.adk.agents import BaseAgent
from google.adk import InvocationContext, Event
from shared.settings import DEFAULT_MODEL
from shared.prompts import BASE_SYSTEM_PROMPT
from tools.pdf_tools import extract_text_from_pdf, chunk_text
from typing import AsyncGenerator


class GeminiPdfProcessedAgent(BaseAgent):
    """
    Custom agent that preprocesses PDF before answering.
    
    This allows us to extract text from the PDF and include it
    in the prompt context.
    """
    
    def __init__(self, pdf_path: str = "data/pdfs/sample.pdf"):
        super().__init__(name="gemini_pdf_processed")
        self.pdf_path = pdf_path
        self.model = DEFAULT_MODEL
        
        # Extract PDF text at initialization
        self.pdf_text = extract_text_from_pdf(pdf_path)
    
    async def _run_async_impl(
        self, 
        ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        """Run the agent with preprocessed PDF content."""
        
        # Get the user's question from the last event
        user_message = ctx.session.events[-1].content.parts[0].text
        
        # Create prompt with PDF content
        full_instruction = BASE_SYSTEM_PROMPT + f"""

You have been provided with the following document content:

---
{self.pdf_text}
---

Answer the following question based on the document above:
{user_message}

Be specific and cite relevant parts of the document.
"""
        
        # Create an LLM agent with the enriched prompt
        llm_agent = Agent(
            name="gemini_pdf_processed",
            model=self.model,
            instruction=full_instruction
        )
        
        # Run the LLM agent and yield its events
        async for event in llm_agent.run_async(ctx):
            yield event


def create_agent(pdf_path: str = "data/pdfs/sample.pdf") -> BaseAgent:
    """
    Create the Gemini PDF Processed agent.
    
    This agent extracts text from a PDF and includes it in the prompt.
    
    Args:
        pdf_path: Path to the PDF file to process
        
    Returns:
        Configured agent instance
    """
    return GeminiPdfProcessedAgent(pdf_path=pdf_path)


# For direct testing
if __name__ == "__main__":
    import asyncio
    from google.adk import Runner
    from google.adk.services import InMemorySessionService
    
    async def test():
        # Note: Using mock PDF text from tools
        agent = create_agent()
        runner = Runner(
            app_name="pdf_qa",
            root_agent=agent,
            session_service=InMemorySessionService()
        )
        
        test_question = "What was the Q3 revenue?"
        print(f"\nQuestion: {test_question}\n")
        print("="*60)
        
        async for event in runner.run_async(
            user_id="test",
            session_id="test_pdf_processed",
            new_message=test_question
        ):
            if event.author == "gemini_pdf_processed" and not event.partial:
                print(f"\n{event.content.parts[0].text}\n")
                print("="*60)
    
    asyncio.run(test())
