# Agent 4: Gemini RAG PDF

## Description

A **Retrieval-Augmented Generation (RAG)** agent that searches through PDF content on-demand. Rather than including the entire document in every prompt, this agent retrieves only relevant sections using search tools.

## Purpose

Demonstrates **scalable document Q&A** - efficient for large documents and multi-turn conversations. Only retrieves what's needed for each question.

## Architecture

- **Model**: gemini-2.0-flash-exp
- **Tools**: vector_search, traditional_search, hybrid_search
- **PDF Access**: On-demand retrieval
- **Processing**: Search-based chunking
- **Complexity**: Medium

## How It Works

1. **Question Analysis**: Agent analyzes what information is needed
2. **Tool Selection**: Decides which search type to use:
   - `vector_search`: Semantic/conceptual queries
   - `traditional_search`: Exact keywords/terms
   - `hybrid_search`: Best of both
3. **Retrieval**: Searches PDF and gets relevant chunks
4. **Synthesis**: Combines retrieved content into answer
5. **Citation**: References which sections were used

## Tool Capabilities

### vector_search
```python
vector_search(
    query="What was the revenue?",
    pdf_name="finance_report",
    top_k=3
)
# Returns semantically similar chunks
```

### traditional_search
```python
traditional_search(
    query="Q3 revenue $45",
    pdf_name="finance_report",
    top_k=3
)
# Returns keyword matches
```

### hybrid_search
```python
hybrid_search(
    query="revenue growth trends",
    pdf_name="finance_report",
    top_k=3
)
# Combined semantic + keyword
```

## Advantages

✅ **Scalable** - Works with huge documents  
✅ **Efficient** - Only retrieves what's needed  
✅ **Context-aware** - Can do multiple searches per question  
✅ **Flexible** - Agent chooses best search strategy  
✅ **Multi-turn friendly** - Doesn't repeat full document  

## Disadvantages

❌ Requires search infrastructure setup  
❌ Quality depends on chunking strategy  
❌ May miss information if search fails  
❌ More complex than simple approaches  

## When to Use

- Large PDFs (100+ pages)
- Multi-turn conversations
- When you need efficiency
- Complex queries requiring multiple lookups
- Production systems with many documents

## Example Usage

```python
from agents.agent_4_gemini_rag_pdf.agent import create_agent

agent = create_agent()
runner = Runner(
    app_name="pdf_qa",
    root_agent=agent,
    session_service=InMemorySessionService()
)

async for event in runner.run_async(
    user_id="user1",
    session_id="session1",
    new_message="What was the Q3 revenue and how does it compare to Q2?"
):
    # Agent will:
    # 1. Call vector_search("Q3 revenue comparison")
    # 2. Get relevant chunks
    # 3. Synthesize answer with citations
    
    if event.author == "gemini_rag_pdf" and not event.partial:
        print(event.content.parts[0].text)
```

## Search Strategy Examples

**Factual Query**:
```
User: "What was the Q3 revenue?"
Agent: Uses traditional_search for exact number
```

**Conceptual Query**:
```
User: "What factors drove growth?"
Agent: Uses vector_search for semantic understanding
```

**Complex Query**:
```
User: "Compare Q3 to Q2 and explain trends"
Agent: Uses hybrid_search + multiple searches
```

## Testing

```bash
# Run the agent directly
python agents/4_gemini_rag_pdf/agent.py

# Or use the CLI
python run_agent.py 4 "What were the key financial highlights?"
```

## Implementation Notes

- Currently uses **mock search tools**
- Real implementation needs:
  - PDF chunking and indexing
  - Vector embeddings (sentence-transformers)
  - Vector store (FAISS, Pinecone, or Vertex AI Search)
  - BM25 for traditional search

## RAG Pipeline (Future)

```
1. Preprocessing:
   - Chunk PDF into segments
   - Create embeddings
   - Build search index

2. Query Time:
   - Agent receives question
   - Agent calls search tool(s)
   - Tool returns ranked chunks
   - Agent synthesizes answer

3. Advantages:
   - Only relevant content in context
   - Can handle massive documents
   - Efficient token usage
```

## Comparison to Other Agents

vs Agent 1-3: Scalable, efficient, but more complex  
vs Agent 5: Simpler than multi-agent, but less structured  
vs Agent 6-8: Self-contained vs external tools  

## Future Enhancements

- [ ] Real vector search implementation
- [ ] BM25 traditional search
- [ ] Query expansion
- [ ] Re-ranking
- [ ] Multiple document support
- [ ] Source attribution
