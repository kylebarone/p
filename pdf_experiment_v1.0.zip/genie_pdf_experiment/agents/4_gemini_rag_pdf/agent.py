"""
Agent 4: Gemini RAG PDF

RAG (Retrieval-Augmented Generation) with search tools.
The agent can search the PDF on-demand using vector, traditional, or hybrid search.
"""

from google.adk import Agent
from shared.settings import DEFAULT_MODEL
from shared.prompts import RAG_SYSTEM_PROMPT
from tools.search_tools import (
    vector_search_tool,
    traditional_search_tool,
    hybrid_search_tool
)


def create_agent() -> Agent:
    """
    Create the Gemini RAG PDF agent.
    
    This agent uses RAG (Retrieval-Augmented Generation):
    1. Receives a question
    2. Decides what information to search for
    3. Uses search tools to find relevant content
    4. Synthesizes answer from retrieved content
    
    The agent has three search tools:
    - vector_search: Semantic/conceptual search
    - traditional_search: Keyword/exact match search
    - hybrid_search: Combined approach
    
    Returns:
        Configured Agent instance with search tools
    """
    return Agent(
        name="gemini_rag_pdf",
        model=DEFAULT_MODEL,
        instruction=RAG_SYSTEM_PROMPT,
        tools=[
            vector_search_tool,
            traditional_search_tool,
            hybrid_search_tool
        ]
    )


# For direct testing
if __name__ == "__main__":
    import asyncio
    from google.adk import Runner
    from google.adk.services import InMemorySessionService
    
    async def test():
        agent = create_agent()
        runner = Runner(
            app_name="pdf_qa",
            root_agent=agent,
            session_service=InMemorySessionService()
        )
        
        test_question = "What was the Q3 revenue and how did it compare to Q2?"
        print(f"\nQuestion: {test_question}\n")
        print("="*60)
        print("\nAgent will use search tools to find relevant information...\n")
        
        async for event in runner.run_async(
            user_id="test",
            session_id="test_rag",
            new_message=test_question
        ):
            # Show tool calls
            if hasattr(event.content, 'parts'):
                for part in event.content.parts:
                    if hasattr(part, 'function_call'):
                        fc = part.function_call
                        print(f"🔧 Calling tool: {fc.name}")
                        print(f"   Args: {fc.args}\n")
            
            # Show final answer
            if event.author == "gemini_rag_pdf" and not event.partial:
                if hasattr(event.content, 'parts') and len(event.content.parts) > 0:
                    text_parts = [p.text for p in event.content.parts if hasattr(p, 'text') and p.text]
                    if text_parts:
                        print(f"\n{text_parts[0]}\n")
                        print("="*60)
    
    asyncio.run(test())
