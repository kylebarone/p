"""
Agent 6: Gemini PDF MCP

Agent that uses an external MCP (Model Context Protocol) server for PDF operations.
Demonstrates external tool integration and separation of concerns.
"""

from google.adk import Agent
from shared.settings import DEFAULT_MODEL
from shared.prompts import MCP_SYSTEM_PROMPT
from tools.mcp_tools import PDF_MCP_TOOLS


def create_agent() -> Agent:
    """
    Create the Gemini PDF MCP agent.
    
    This agent uses MCP (Model Context Protocol) to interact with PDFs.
    The MCP server handles all PDF operations externally, and the agent
    calls it through tools.
    
    Available MCP operations:
    - read_pdf: Read content from specific pages
    - search_pdf: Search within the document
    - extract_sections: Get specific sections (headers, tables, etc.)
    
    This demonstrates:
    - External tool integration
    - Separation of PDF logic from agent logic
    - Modular architecture
    
    Returns:
        Configured Agent instance with MCP tools
    """
    return Agent(
        name="gemini_pdf_mcp",
        model=DEFAULT_MODEL,
        instruction=MCP_SYSTEM_PROMPT,
        tools=PDF_MCP_TOOLS
    )


# For direct testing
if __name__ == "__main__":
    import asyncio
    from google.adk import Runner
    from google.adk.services import InMemorySessionService
    
    async def test():
        agent = create_agent()
        runner = Runner(
            app_name="pdf_qa",
            root_agent=agent,
            session_service=InMemorySessionService()
        )
        
        test_question = "What were the key financial metrics in Q3?"
        print(f"\nQuestion: {test_question}\n")
        print("="*60)
        print("\nAgent will use MCP server for PDF operations...\n")
        
        async for event in runner.run_async(
            user_id="test",
            session_id="test_mcp",
            new_message=test_question
        ):
            # Show MCP tool calls
            if hasattr(event.content, 'parts'):
                for part in event.content.parts:
                    if hasattr(part, 'function_call'):
                        fc = part.function_call
                        print(f"🔧 MCP Call: {fc.name}")
                        print(f"   Args: {fc.args}\n")
            
            # Show final answer
            if event.author == "gemini_pdf_mcp" and not event.partial:
                if hasattr(event.content, 'parts') and len(event.content.parts) > 0:
                    text_parts = [p.text for p in event.content.parts if hasattr(p, 'text') and p.text]
                    if text_parts:
                        print(f"\n{text_parts[0]}\n")
                        print("="*60)
    
    asyncio.run(test())
