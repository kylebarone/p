# Agent 6: Gemini PDF MCP

## Description

An agent that uses **MCP (Model Context Protocol)** to interact with PDFs through an external server. Demonstrates clean separation between agent logic and PDF operations.

## Purpose

Shows **external tool integration** via MCP - a standardized protocol for connecting AI models to external services and tools.

## Architecture

- **Model**: gemini-2.0-flash-exp
- **Tools**: MCP PDF tools (read_pdf, search_pdf, extract_sections)
- **External Service**: MCP server (handles PDF operations)
- **Complexity**: Medium-High

## MCP (Model Context Protocol)

MCP is a protocol for standardizing how AI models interact with external tools and data sources. Key benefits:

- **Separation of Concerns**: PDF logic is external
- **Reusability**: Same MCP server can serve multiple agents/models
- **Standardization**: Common interface across tools
- **Scalability**: Server can handle resources, caching, etc.

## Available MCP Operations

### read_pdf
```python
read_pdf(
    pdf_name="finance_report",
    pages=[2, 3, 5]  # Optional: specific pages
)
# Returns: Content from specified pages
```

### search_pdf
```python
search_pdf(
    pdf_name="finance_report",
    query="Q3 revenue",
    search_type="semantic"  # or "keyword"
)
# Returns: Matching sections with relevance scores
```

### extract_sections
```python
extract_sections(
    pdf_name="finance_report",
    section_type="tables"  # or "headers", "figures", "all"
)
# Returns: Extracted structured content
```

## How It Works

```
┌─────────────────┐
│   ADK Agent     │
│ (Gemini LLM)    │
└────────┬────────┘
         │ calls tool
         ▼
┌─────────────────┐
│  MCP Client     │
│  (Tool Wrapper) │
└────────┬────────┘
         │ protocol
         ▼
┌─────────────────┐
│  MCP Server     │
│ (PDF Operations)│
└────────┬────────┘
         │ accesses
         ▼
┌─────────────────┐
│   PDF Files     │
└─────────────────┘
```

## Advantages

✅ **Clean separation** - Agent doesn't handle PDF logic  
✅ **Reusable** - MCP server can serve multiple agents  
✅ **Scalable** - Server can be separate service  
✅ **Maintainable** - Update PDF logic without touching agent  
✅ **Standardized** - MCP is an emerging standard  

## Disadvantages

❌ Additional infrastructure (MCP server)  
❌ Network latency (if server is remote)  
❌ More moving parts  
❌ Debugging across boundaries  

## When to Use

- Production systems with multiple agents
- When PDF operations are complex/expensive
- When you want to separate concerns
- When sharing tools across models/agents
- Microservices architecture

## Example Usage

```python
from agents.agent_6_gemini_pdf_mcp.agent import create_agent

agent = create_agent()
runner = Runner(
    app_name="pdf_qa",
    root_agent=agent,
    session_service=InMemorySessionService()
)

async for event in runner.run_async(
    user_id="user1",
    session_id="session1",
    new_message="What tables are in the document?"
):
    # Agent will:
    # 1. Call extract_sections(section_type="tables")
    # 2. MCP server processes PDF
    # 3. Returns structured table data
    # 4. Agent synthesizes answer
    
    if event.author == "gemini_pdf_mcp" and not event.partial:
        print(event.content.parts[0].text)
```

## Agent Workflow Example

```
User: "What was the Q3 revenue?"

Agent thinks: "I need to search the PDF"
    ↓
Agent calls: search_pdf("Q3 revenue", search_type="keyword")
    ↓
MCP server searches PDF, returns chunks
    ↓
Agent receives: [{"page": 3, "content": "Q3 revenue: $45.3M", ...}]
    ↓
Agent synthesizes: "According to page 3, Q3 revenue was $45.3M"
```

## Testing

```bash
# Run the agent directly
python agents/6_gemini_pdf_mcp/agent.py

# Or use the CLI
python run_agent.py 6 "Extract the key metrics from the document"
```

## Implementation Notes

- Currently uses **mock MCP server** (functions in mcps/pdf_server.py)
- Real implementation would use MCP SDK and run as separate process
- Tools are wrapped as ADK FunctionTools

## MCP Server Setup (Future)

```python
# Real MCP server setup
from mcp import Server

server = Server("pdf-server")

@server.tool()
def read_pdf(pdf_name: str, pages: list[int] = None):
    # Real PDF reading
    pass

@server.tool()
def search_pdf(pdf_name: str, query: str):
    # Real search
    pass

server.run(port=8000)
```

Then agents connect to this server via MCP protocol.

## Comparison to Other Agents

vs Agent 4 (RAG): External vs internal tools  
vs Agent 5 (Multi-agent): Single agent with external tools  
vs Agent 7: Same tools, but Agent 7 adds scratchpad  
vs Agent 3: External vs built-in processing  

## Future Enhancements

- [ ] Real MCP server implementation
- [ ] Remote MCP server deployment
- [ ] Additional PDF operations (annotations, metadata)
- [ ] Caching in MCP server
- [ ] Multi-document support
- [ ] Authentication/authorization
