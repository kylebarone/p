"""
Agent 7: Gemini PDF MCP Stateful

MCP agent with scratchpad capabilities for note-taking and stateful reasoning.
Demonstrates how agents can maintain working memory across multiple tool calls.
"""

from google.adk import Agent
from shared.settings import DEFAULT_MODEL
from shared.prompts import MCP_STATEFUL_PROMPT
from tools.mcp_tools import ALL_MCP_TOOLS


def create_agent() -> Agent:
    """
    Create the Gemini PDF MCP Stateful agent.
    
    This agent has all MCP PDF operations PLUS scratchpad tools:
    - write_note: Store information in scratchpad
    - read_note: Retrieve stored information
    - list_notes: See all stored notes
    
    The scratchpad allows the agent to:
    - Build up knowledge iteratively
    - Track multiple pieces of information
    - Reason across multiple tool calls
    - Organize findings before synthesizing
    
    This demonstrates stateful, iterative reasoning where the agent
    can "think" by taking notes and referring back to them.
    
    Returns:
        Configured Agent instance with MCP + scratchpad tools
    """
    return Agent(
        name="gemini_pdf_mcp_stateful",
        model=DEFAULT_MODEL,
        instruction=MCP_STATEFUL_PROMPT,
        tools=ALL_MCP_TOOLS  # PDF tools + scratchpad tools
    )


# For direct testing
if __name__ == "__main__":
    import asyncio
    from google.adk import Runner
    from google.adk.services import InMemorySessionService
    
    async def test():
        agent = create_agent()
        runner = Runner(
            app_name="pdf_qa",
            root_agent=agent,
            session_service=InMemorySessionService()
        )
        
        test_question = "What were the Q3 financial highlights and how do they compare to Q2?"
        print(f"\nQuestion: {test_question}\n")
        print("="*60)
        print("\nAgent will use MCP + Scratchpad for iterative reasoning...\n")
        
        async for event in runner.run_async(
            user_id="test",
            session_id="test_mcp_stateful",
            new_message=test_question
        ):
            # Show all tool calls
            if hasattr(event.content, 'parts'):
                for part in event.content.parts:
                    if hasattr(part, 'function_call'):
                        fc = part.function_call
                        tool_type = "📝 Scratchpad" if "note" in fc.name else "🔧 MCP PDF"
                        print(f"{tool_type}: {fc.name}({fc.args})")
            
            # Show final answer
            if event.author == "gemini_pdf_mcp_stateful" and not event.partial:
                if hasattr(event.content, 'parts') and len(event.content.parts) > 0:
                    text_parts = [p.text for p in event.content.parts if hasattr(p, 'text') and p.text]
                    if text_parts:
                        print(f"\n📊 Final Answer:\n{text_parts[0]}\n")
                        print("="*60)
    
    asyncio.run(test())
