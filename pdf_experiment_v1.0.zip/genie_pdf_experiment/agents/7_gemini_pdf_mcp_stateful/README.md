# Agent 7: Gemini PDF MCP Stateful

## Description

An MCP agent enhanced with **scratchpad capabilities** for taking notes and maintaining working memory. Enables iterative, stateful reasoning across multiple tool calls.

## Purpose

Demonstrates **stateful agentic reasoning** - the agent can "think" by taking notes, organizing information, and building knowledge incrementally.

## Architecture

- **Model**: gemini-2.0-flash-exp
- **Tools**: MCP PDF tools + Scratchpad tools
- **State Management**: Explicit via note-taking tools
- **Complexity**: High

## All Available Tools

### PDF Operations (from MCP server)
- `read_pdf` - Read PDF pages
- `search_pdf` - Search PDF content
- `extract_sections` - Extract structured content

### Scratchpad Operations
- `write_note(key, value)` - Store information
- `read_note(key)` - Retrieve information
- `list_notes()` - See all notes

## How It Works

The agent can reason iteratively:

```
1. Search PDF for Q3 data
   → write_note("q3_revenue", "$45.3M")

2. Search PDF for Q2 data
   → write_note("q2_revenue", "$40.5M")

3. Read both notes
   → Calculate: 45.3 / 40.5 = 11.9% growth

4. Synthesize answer with context
```

This is more sophisticated than single-pass retrieval because the agent builds up knowledge before answering.

## Workflow Example

```
User: "Compare Q3 and Q2 revenue, and identify growth drivers"

Agent workflow:
┌──────────────────────────────────────────────┐
│ Step 1: search_pdf("Q3 revenue")            │
│ Result: "$45.3M in Q3"                       │
│ Action: write_note("q3_revenue", "45.3M")   │
└──────────────────────────────────────────────┘
┌──────────────────────────────────────────────┐
│ Step 2: search_pdf("Q2 revenue")            │
│ Result: "$40.5M in Q2"                       │
│ Action: write_note("q2_revenue", "40.5M")   │
└──────────────────────────────────────────────┘
┌──────────────────────────────────────────────┐
│ Step 3: search_pdf("revenue growth factors")│
│ Result: "Enterprise adoption, new features"  │
│ Action: write_note("drivers", "...")         │
└──────────────────────────────────────────────┘
┌──────────────────────────────────────────────┐
│ Step 4: list_notes()                         │
│ Review all collected information             │
└──────────────────────────────────────────────┘
┌──────────────────────────────────────────────┐
│ Step 5: Synthesize comprehensive answer     │
│ "Q3 revenue was $45.3M vs Q2's $40.5M..."   │
└──────────────────────────────────────────────┘
```

## Advantages

✅ **Iterative reasoning** - Build knowledge step-by-step  
✅ **Complex queries** - Handle multi-part questions  
✅ **Organized thinking** - Explicit note structure  
✅ **Debuggable** - Can see agent's "thought process"  
✅ **Flexible** - Agent decides what to remember  

## Disadvantages

❌ More tool calls (higher latency)  
❌ Requires careful prompting  
❌ Can be overkill for simple questions  
❌ More complex to debug  

## When to Use

- Complex, multi-part questions
- Questions requiring synthesis across multiple searches
- When you want visible "thinking" process
- Research-style tasks
- Comparative analyses

## Example Usage

```python
from agents.agent_7_gemini_pdf_mcp_stateful.agent import create_agent

agent = create_agent()
runner = Runner(
    app_name="pdf_qa",
    root_agent=agent,
    session_service=InMemorySessionService()
)

async for event in runner.run_async(
    user_id="user1",
    session_id="session1",
    new_message="Compare Q3 to Q2 revenue and explain the key drivers of growth"
):
    # You'll see the agent:
    # 1. Search for Q3 data → write_note
    # 2. Search for Q2 data → write_note
    # 3. Search for growth drivers → write_note
    # 4. list_notes to review
    # 5. Synthesize comprehensive answer
    
    if event.author == "gemini_pdf_mcp_stateful" and not event.partial:
        print(event.content.parts[0].text)
```

## Scratchpad Use Cases

### Use Case 1: Accumulating Facts
```
Question: "List all the key metrics from the report"

Agent workflow:
- search_pdf("revenue") → write_note("metric_1", ...)
- search_pdf("customers") → write_note("metric_2", ...)
- search_pdf("margins") → write_note("metric_3", ...)
- list_notes() → Synthesize comprehensive list
```

### Use Case 2: Comparative Analysis
```
Question: "How do Q1, Q2, Q3 compare?"

Agent workflow:
- Get Q1 data → write_note("q1", ...)
- Get Q2 data → write_note("q2", ...)
- Get Q3 data → write_note("q3", ...)
- Read all notes → Create comparison table
```

### Use Case 3: Multi-Step Reasoning
```
Question: "What's the implication of the revenue trend?"

Agent workflow:
- Collect revenue data → write_note("trend_data", ...)
- Calculate growth rate → write_note("growth_rate", ...)
- Search for context → write_note("market_context", ...)
- Synthesize implications using all notes
```

## Testing

```bash
# Run the agent directly
python agents/7_gemini_pdf_mcp_stateful/agent.py

# Or use the CLI
python run_agent.py 7 "Compare Q3 to Q2 and explain what drove the changes"
```

## Implementation Notes

- Scratchpad is currently in-memory (mcps/pdf_server.py)
- Real implementation could use:
  - Session state (ADK's session.state)
  - External key-value store (Redis)
  - Database
  - File system

## Scratchpad vs Session State

**Scratchpad (tools)**:
- Explicit operations
- Agent controls what to store
- Visible in tool calls
- Great for debugging

**Session State (ADK)**:
- Automatic via state_delta
- More integrated with ADK
- Less visible

Both approaches work! This agent demonstrates the explicit tool approach.

## Comparison to Other Agents

vs Agent 6 (MCP): Adds scratchpad for stateful reasoning  
vs Agent 5 (Multi-agent): Single agent with working memory  
vs Agent 4 (RAG): More sophisticated reasoning process  

## Future Enhancements

- [ ] Persistent scratchpad (database)
- [ ] Structured notes (JSON, not just strings)
- [ ] Note templates for common patterns
- [ ] Automatic summarization of notes
- [ ] Sharing notes across sessions
- [ ] Note expiration/cleanup
