"""
Agent 2: Gemini PDF Part

LLM with native PDF understanding through multimodal input.
The PDF is attached directly to the message.
"""

from google.adk import Agent
from shared.settings import DEFAULT_MODEL
from shared.prompts import BASE_SYSTEM_PROMPT


def create_agent() -> Agent:
    """
    Create the Gemini PDF Part agent.
    
    This agent receives the PDF as a multimodal input (like an image).
    Gemini can natively "see" and understand the PDF structure.
    
    The user should attach the PDF file when sending their message,
    and Gemini will process it directly.
    
    Returns:
        Configured Agent instance
    """
    return Agent(
        name="gemini_pdf_part",
        model=DEFAULT_MODEL,
        instruction=BASE_SYSTEM_PROMPT + """

You have been provided with a PDF document as part of the conversation.
You can "see" and understand the document's content, including:
- Text content
- Document structure
- Layout and formatting

Answer questions based on what you can observe in the provided PDF.
When citing information, reference the specific sections or pages you used.
"""
    )


# For direct testing
if __name__ == "__main__":
    import asyncio
    from google.adk import Runner
    from google.adk.services import InMemorySessionService
    
    async def test():
        agent = create_agent()
        runner = Runner(
            app_name="pdf_qa",
            root_agent=agent,
            session_service=InMemorySessionService()
        )
        
        # Note: In real usage, the PDF would be attached to the message
        test_question = "What are the main topics covered in this document?"
        print(f"\nQuestion: {test_question}\n")
        print("NOTE: This agent expects a PDF to be attached to the message.")
        print("In this test mode, it will respond as if a PDF were present.\n")
        print("="*60)
        
        async for event in runner.run_async(
            user_id="test",
            session_id="test_pdf_part",
            new_message=test_question
        ):
            if event.author == "gemini_pdf_part" and not event.partial:
                print(f"\n{event.content.parts[0].text}\n")
                print("="*60)
    
    asyncio.run(test())
