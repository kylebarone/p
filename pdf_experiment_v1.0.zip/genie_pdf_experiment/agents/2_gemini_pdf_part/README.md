# Agent 2: Gemini PDF Part (Multimodal)

## Description

This agent leverages Gemini's native multimodal capabilities to directly process PDF files. The PDF is provided as an attachment in the conversation, and Gemini can "see" and understand its content without explicit text extraction.

## Purpose

Demonstrates **native PDF understanding** - no preprocessing required. Gemini treats the PDF like an image and can comprehend both content and structure.

## Architecture

- **Model**: gemini-2.0-flash-exp (multimodal)
- **Tools**: None
- **PDF Access**: Direct (as multimodal input)
- **Processing**: None required - native PDF understanding
- **Complexity**: Low

## How It Works

1. User attaches PDF file to their message
2. Gemini receives PDF as multimodal input (similar to image)
3. Model processes the document natively
4. Returns answer based on document content

## Advantages

✅ No preprocessing overhead  
✅ Can understand document layout and structure  
✅ Preserves visual elements  
✅ Simple implementation  

## Disadvantages

❌ Limited by context window (large PDFs may be truncated)  
❌ Cannot selectively retrieve specific sections  
❌ Entire PDF must be in context for each query  
❌ Less efficient for multi-turn conversations about same doc  

## When to Use

- Small to medium PDFs (under ~50 pages)
- Questions requiring understanding of document structure/layout
- Simple one-off queries
- When you want zero preprocessing

## Example Usage

```python
from agents.agent_2_gemini_pdf_part.agent import create_agent
from google.adk import Runner
from google.adk.services import InMemorySessionService

agent = create_agent()
runner = Runner(
    app_name="pdf_qa",
    root_agent=agent,
    session_service=InMemorySessionService()
)

# User would attach PDF when sending message through UI
async for event in runner.run_async(
    user_id="user1",
    session_id="session1",
    new_message="What was the Q3 revenue?",
    # PDF attachment handled by frontend/runner
):
    if event.author == "gemini_pdf_part" and not event.partial:
        print(event.content.parts[0].text)
```

## Testing

```bash
# Run the agent directly
python agents/2_gemini_pdf_part/agent.py

# Or use the CLI (with PDF attachment in real usage)
python run_agent.py 2 "Summarize this document"
```

## Implementation Notes

- The PDF is passed as part of the message content
- No explicit text extraction happens
- Gemini processes the document as a multimodal input
- Similar to how it processes images

## Comparison to Other Agents

vs Agent 1 (Base): Adds PDF access  
vs Agent 3 (Processed): More natural, less control  
vs Agent 4-5 (RAG): Better for small docs, less efficient for large  
vs Agent 6-8 (MCP): Simpler, but less flexible  
