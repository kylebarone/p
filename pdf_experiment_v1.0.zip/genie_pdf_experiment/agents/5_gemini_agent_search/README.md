# Agent 5: Gemini Agent Search

## Description

A **multi-agent workflow** that explicitly orchestrates three specialized sub-agents to answer questions. Demonstrates structured agentic reasoning vs single-agent approaches.

## Purpose

Shows **explicit agent orchestration** using ADK's SequentialAgent. Each sub-agent has a specific role, and they work together in a pipeline.

## Architecture

- **Type**: SequentialAgent (3 sub-agents)
- **Model**: gemini-2.0-flash-exp (for each sub-agent)
- **Tools**: vector_search, hybrid_search (on searcher agent)
- **Complexity**: High

## The Three Agents

### 1. Question Analyzer
**Role**: Understand and plan

**Input**: User question  
**Output**: Analysis stored in `session.state["analysis"]`

**Tasks**:
- Break down the question
- Identify what information is needed
- Determine best search strategy
- Note any sub-questions

**Example**:
```
Question: "What drove Q3 revenue growth?"
Analysis: {
  "info_needed": ["Q3 revenue figures", "growth factors", "YoY comparison"],
  "search_strategy": "semantic search for 'revenue drivers' and 'growth factors'",
  "complexity": "medium"
}
```

### 2. Searcher
**Role**: Gather information

**Input**: Analysis from step 1  
**Output**: Search results stored in `session.state["search_results"]`

**Tools**: vector_search, hybrid_search

**Tasks**:
- Execute searches based on analysis
- Retrieve relevant chunks
- Possibly do multiple searches
- Organize findings

**Example**:
```
Searches:
- vector_search("revenue growth factors Q3")
- vector_search("performance drivers")

Results: [list of relevant chunks with citations]
```

### 3. Synthesizer
**Role**: Create final answer

**Input**: Analysis + Search results from state  
**Output**: Comprehensive answer

**Tasks**:
- Review all gathered information
- Synthesize coherent response
- Include citations
- Address original question fully

## How It Works

```
User Question
     ↓
[Analyzer] → Analysis stored in state
     ↓
[Searcher] → Uses analysis, searches, stores results
     ↓
[Synthesizer] → Uses analysis + results, creates answer
     ↓
Final Answer to User
```

## Advantages

✅ **Structured reasoning** - Clear separation of concerns  
✅ **Debuggable** - Can inspect each step's output  
✅ **Explicit control** - Deterministic pipeline  
✅ **Extensible** - Easy to add steps  
✅ **Transparent** - Can see the agent's "thinking"  

## Disadvantages

❌ More complex to implement  
❌ Rigid structure (always 3 steps)  
❌ Potentially slower (3 LLM calls minimum)  
❌ Over-engineered for simple questions  

## When to Use

- Complex questions requiring structured approach
- When you want explicit reasoning steps
- Debugging and development
- Educational purposes (show agent orchestration)
- Tasks that naturally decompose into steps

## Example Usage

```python
from agents.agent_5_gemini_agent_search.agent import create_agent

agent = create_agent()  # Returns a SequentialAgent

runner = Runner(
    app_name="pdf_qa",
    root_agent=agent,
    session_service=InMemorySessionService()
)

async for event in runner.run_async(
    user_id="user1",
    session_id="session1",
    new_message="What were the main drivers of Q3 revenue growth?"
):
    # You'll see events from:
    # 1. question_analyzer
    # 2. searcher (with tool calls)
    # 3. synthesizer (final answer)
    
    if event.author == "synthesizer" and not event.partial:
        print(event.content.parts[0].text)
```

## State Usage

This agent makes heavy use of `session.state`:

```python
# After analyzer runs:
session.state["analysis"] = "..."

# After searcher runs:
session.state["search_results"] = [...]

# Synthesizer reads both to create answer
```

## Testing

```bash
# Run the agent directly
python agents/5_gemini_agent_search/agent.py

# Or use the CLI
python run_agent.py 5 "What factors contributed to the results?"
```

## Workflow Visualization

```
┌─────────────────────────────────────────────────────────┐
│                     User Question                       │
└────────────────────┬────────────────────────────────────┘
                     │
              ┌──────▼──────┐
              │  Analyzer   │
              │ (Agent 1)   │
              └──────┬──────┘
                     │ stores: session.state["analysis"]
              ┌──────▼──────┐
              │  Searcher   │
              │ (Agent 2)   │ Uses: vector_search_tool
              └──────┬──────┘
                     │ stores: session.state["search_results"]
              ┌──────▼──────┐
              │ Synthesizer │
              │ (Agent 3)   │
              └──────┬──────┘
                     │
              ┌──────▼──────┐
              │Final Answer │
              └─────────────┘
```

## Comparison to Other Agents

vs Agent 4 (RAG): More structured, explicit reasoning  
vs Agent 6-8 (MCP): Internal orchestration vs external tools  
vs Agent 1-3: Much more sophisticated  

## Future Enhancements

- [ ] Add conditional branching (if analysis says X, do Y)
- [ ] Add a critic agent for quality checking
- [ ] Support parallel searches (ParallelAgent)
- [ ] Add retry logic for failed searches
- [ ] Dynamic sub-agent selection
