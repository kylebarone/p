"""
Agent 5: Gemini Agent Search

Multi-agent workflow with explicit orchestration.
Uses SequentialAgent to coordinate: analyze → search → synthesize.
"""

from google.adk import Agent
from google.adk.agents import SequentialAgent, BaseAgent
from shared.settings import DEFAULT_MODEL
from shared.prompts import AGENT_SEARCH_PROMPTS
from tools.search_tools import vector_search_tool, hybrid_search_tool


def create_agent() -> BaseAgent:
    """
    Create the Gemini Agent Search system.
    
    This is a **multi-agent workflow** that breaks the task into steps:
    
    1. **Analyzer**: Understands the question and plans search strategy
    2. **Searcher**: Executes searches and gathers information
    3. **Synthesizer**: Creates final answer from results
    
    Each sub-agent has a specific role, and they work sequentially.
    This demonstrates explicit orchestration vs single-agent RAG.
    
    Returns:
        SequentialAgent coordinating three sub-agents
    """
    
    # Agent 1: Question Analyzer
    analyzer = Agent(
        name="question_analyzer",
        model=DEFAULT_MODEL,
        instruction=AGENT_SEARCH_PROMPTS["analyzer"],
        output_key="analysis"  # Store analysis in session.state
    )
    
    # Agent 2: Searcher
    searcher = Agent(
        name="searcher",
        model=DEFAULT_MODEL,
        instruction=AGENT_SEARCH_PROMPTS["searcher"] + """

Review the analysis from the previous step (in session state under 'analysis').
Use the appropriate search tools based on that analysis.
Gather all relevant information.""",
        tools=[vector_search_tool, hybrid_search_tool],
        output_key="search_results"  # Store results in session.state
    )
    
    # Agent 3: Synthesizer
    synthesizer = Agent(
        name="synthesizer",
        model=DEFAULT_MODEL,
        instruction=AGENT_SEARCH_PROMPTS["synthesizer"] + """

Review:
- The original analysis (from 'analysis' in state)
- The search results (from 'search_results' in state)

Create a comprehensive, well-cited answer."""
    )
    
    # Orchestrate them in sequence
    return SequentialAgent(
        name="gemini_agent_search",
        sub_agents=[analyzer, searcher, synthesizer]
    )


# For direct testing
if __name__ == "__main__":
    import asyncio
    from google.adk import Runner
    from google.adk.services import InMemorySessionService
    
    async def test():
        agent = create_agent()
        runner = Runner(
            app_name="pdf_qa",
            root_agent=agent,
            session_service=InMemorySessionService()
        )
        
        test_question = "What were the main drivers of Q3 revenue growth?"
        print(f"\nQuestion: {test_question}\n")
        print("="*60)
        print("\nMulti-Agent Workflow:")
        print("1. Analyzer will analyze the question")
        print("2. Searcher will search for information")
        print("3. Synthesizer will create final answer\n")
        
        current_agent = None
        async for event in runner.run_async(
            user_id="test",
            session_id="test_agent_search",
            new_message=test_question
        ):
            # Track which agent is speaking
            if event.author != "user" and event.author != current_agent:
                current_agent = event.author
                print(f"\n🤖 {current_agent} is working...\n")
            
            # Show tool calls
            if hasattr(event.content, 'parts'):
                for part in event.content.parts:
                    if hasattr(part, 'function_call'):
                        fc = part.function_call
                        print(f"  🔧 Calling: {fc.name}")
            
            # Show final output from synthesizer
            if event.author == "synthesizer" and not event.partial:
                if hasattr(event.content, 'parts') and len(event.content.parts) > 0:
                    text_parts = [p.text for p in event.content.parts if hasattr(p, 'text') and p.text]
                    if text_parts:
                        print(f"\n📝 Final Answer:\n{text_parts[0]}\n")
                        print("="*60)
    
    asyncio.run(test())
