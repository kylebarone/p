# Genie PDF Experiment

**Exploring 8 Different Approaches to PDF Question-Answering with Google ADK**

## Overview

This repository demonstrates a spectrum of AI agent architectures for answering questions about PDF documents, from simple baseline models to sophisticated multi-agent systems with external tools.

## The 8 Agent Implementations

Each agent represents a different level of engineering sophistication:

| # | Agent | Description | Key Feature |
|---|-------|-------------|-------------|
| 1 | **Gemini Base** | Raw LLM, no PDF access | Baseline - training knowledge only |
| 2 | **Gemini PDF Part** | LLM with PDF as multimodal input | Native PDF understanding |
| 3 | **Gemini PDF Processed** | LLM with extracted text | Preprocessing pipeline |
| 4 | **Gemini RAG PDF** | RAG with search tools | Retrieval-augmented generation |
| 5 | **Gemini Agent Search** | Multi-step agentic workflow | Orchestrated sub-agents |
| 6 | **Gemini PDF MCP** | Agent with MCP server | External tool integration |
| 7 | **Gemini PDF MCP Stateful** | MCP with scratchpad | Stateful reasoning |
| 8 | **Gemini Multimodal** | Advanced PDF with visuals | Text + visual understanding |

## Quick Start

### Installation

```bash
# Clone the repository
git clone <repo-url>
cd genie_pdf_experiment

# Install dependencies
pip install -r requirements.txt

# Set up Google API key
export GOOGLE_API_KEY="your-api-key"
```

### Running an Agent

```bash
# Run agent #1 (Gemini Base)
python run_agent.py 1 "What is machine learning?"

# Run agent #4 (RAG) with a question
python run_agent.py 4 "What was the Q3 revenue in the finance report?"

# Test an agent directly
python agents/1_gemini_base/agent.py
```

### Deploying with ADK Web

```bash
# Deploy a single agent
adk web --agent agents/4_gemini_rag_pdf/agent.py

# Or run locally for testing
python -m agents.4_gemini_rag_pdf.agent
```

## Project Structure

```
genie_pdf_experiment/
├── agents/              # 8 different agent implementations
│   ├── 1_gemini_base/
│   ├── 2_gemini_pdf_part/
│   ├── 3_gemini_pdf_processed/
│   ├── 4_gemini_rag_pdf/
│   ├── 5_gemini_agent_search/
│   ├── 6_gemini_pdf_mcp/
│   ├── 7_gemini_pdf_mcp_stateful/
│   └── 8_gemini_multimodal/
├── tools/               # Shared PDF and search tools
├── mcps/                # MCP server implementations
├── shared/              # Common prompts and settings
├── data/                # PDFs and test questions
└── run_agent.py         # CLI for testing agents
```

## Adding Test PDFs

Place your PDF files in `data/pdfs/`:

```bash
cp your-document.pdf data/pdfs/
```

## Development Status

### Current Phase: Scaffolding with Mocks

All agents are implemented with **mock tools** that return sample data. This allows testing the agent logic and orchestration without real PDF processing or search infrastructure.

### Next Steps

1. **Implement Real Tools** - Replace mocks with actual PDF extraction, chunking, and search
2. **Build MCP Server** - Create functional MCP server for agents 6 & 7
3. **Test & Refine** - Run all agents on real PDFs and refine prompts
4. **Deploy** - Make agents available via ADK Web

## Agent Details

Each agent directory contains:
- `agent.py` - Agent implementation with `create_agent()` function
- `README.md` - Detailed description, architecture, and usage

See individual agent READMEs for specific details on how each works.

## Tools

### PDF Tools (`tools/pdf_tools.py`)
- `extract_text_from_pdf(pdf_path)` - Extract all text from PDF
- `chunk_text(text, chunk_size)` - Split text into chunks
- `extract_pages(pdf_path, pages)` - Extract specific pages

### Search Tools (`tools/search_tools.py`)
- `vector_search(query, pdf_name, top_k)` - Semantic search with embeddings
- `traditional_search(query, pdf_name, top_k)` - Keyword search (BM25)
- `hybrid_search(query, pdf_name, top_k)` - Combined approach

**Note**: Currently using mock implementations. Real implementations coming in next phase.

## Use Cases

This experiment is designed to:

1. **Compare Approaches** - Understand tradeoffs between different architectures
2. **Educational** - Learn about agent orchestration, RAG, and MCP
3. **Production Reference** - Guide decisions for real-world implementations
4. **Client Demos** - Show the spectrum from basic to advanced AI systems

## License

MIT

## Contributing

This is an experimental/educational repository. Feel free to:
- Test different prompts
- Add new agent variants
- Implement real tool functions
- Compare results across agents

---

**Built with [Google Agent Development Kit (ADK)](https://github.com/google/adk)**
