#!/usr/bin/env python3
"""
CLI for running any of the 8 PDF Q&A agents.

Usage:
    python run_agent.py <agent_num> "<question>"
    
Examples:
    python run_agent.py 1 "What is machine learning?"
    python run_agent.py 4 "What was the Q3 revenue?"
    python run_agent.py 7 "Compare Q3 and Q2 performance"
"""

import asyncio
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from google.adk import Runner
from google.adk.services import InMemorySessionService

# Import all agent creators
from agents.agent_1_gemini_base.agent import create_agent as create_agent_1
from agents.agent_2_gemini_pdf_part.agent import create_agent as create_agent_2
from agents.agent_3_gemini_pdf_processed.agent import create_agent as create_agent_3
from agents.agent_4_gemini_rag_pdf.agent import create_agent as create_agent_4
from agents.agent_5_gemini_agent_search.agent import create_agent as create_agent_5
from agents.agent_6_gemini_pdf_mcp.agent import create_agent as create_agent_6
from agents.agent_7_gemini_pdf_mcp_stateful.agent import create_agent as create_agent_7
from agents.agent_8_gemini_multimodal.agent import create_agent as create_agent_8


AGENTS = {
    "1": ("Gemini Base", "gemini_base", create_agent_1),
    "2": ("Gemini PDF Part", "gemini_pdf_part", create_agent_2),
    "3": ("Gemini PDF Processed", "gemini_pdf_processed", create_agent_3),
    "4": ("Gemini RAG PDF", "gemini_rag_pdf", create_agent_4),
    "5": ("Gemini Agent Search", "gemini_agent_search", create_agent_5),
    "6": ("Gemini PDF MCP", "gemini_pdf_mcp", create_agent_6),
    "7": ("Gemini PDF MCP Stateful", "gemini_pdf_mcp_stateful", create_agent_7),
    "8": ("Gemini Multimodal", "gemini_multimodal", create_agent_8),
}


def print_agents():
    """Print available agents."""
    print("\n📚 Available Agents:\n")
    for num, (name, agent_name, _) in AGENTS.items():
        print(f"  {num}. {name} ({agent_name})")
    print()


def print_usage():
    """Print usage instructions."""
    print("\n🚀 PDF Q&A Agent Runner\n")
    print("Usage:")
    print('  python run_agent.py <agent_num> "<question>"')
    print("\nExamples:")
    print('  python run_agent.py 1 "What is machine learning?"')
    print('  python run_agent.py 4 "What was the Q3 revenue?"')
    print('  python run_agent.py 7 "Compare Q3 and Q2 performance"')
    print_agents()


async def run_agent(agent_num: str, question: str, verbose: bool = False):
    """
    Run specified agent with question.
    
    Args:
        agent_num: Agent number (1-8)
        question: Question to ask
        verbose: Show detailed events
    """
    if agent_num not in AGENTS:
        print(f"❌ Unknown agent: {agent_num}")
        print_agents()
        return
    
    name, agent_name, create_fn = AGENTS[agent_num]
    
    # Print header
    print("\n" + "="*70)
    print(f"🤖 Running: {name}")
    print(f"Agent ID: {agent_name}")
    print(f"Question: {question}")
    print("="*70 + "\n")
    
    # Create agent
    try:
        if agent_num == "3":
            # Agent 3 needs PDF path
            agent = create_fn(pdf_path="data/pdfs/sample.pdf")
        else:
            agent = create_fn()
    except Exception as e:
        print(f"❌ Error creating agent: {e}")
        return
    
    # Create runner
    runner = Runner(
        app_name="pdf_qa",
        root_agent=agent,
        session_service=InMemorySessionService()
    )
    
    # Run agent
    try:
        current_agent = None
        tool_calls = []
        
        async for event in runner.run_async(
            user_id="cli_user",
            session_id=f"cli_{agent_num}",
            new_message=question
        ):
            # Track which agent is speaking (for multi-agent systems)
            if event.author != "user" and event.author != current_agent:
                current_agent = event.author
                if verbose and current_agent != agent_name:
                    print(f"\n🔄 Sub-agent: {current_agent}\n")
            
            # Show tool calls if verbose
            if verbose and hasattr(event.content, 'parts'):
                for part in event.content.parts:
                    if hasattr(part, 'function_call'):
                        fc = part.function_call
                        print(f"  🔧 Tool: {fc.name}({fc.args})")
                        tool_calls.append(fc.name)
            
            # Show final answer
            if not event.partial:
                if hasattr(event.content, 'parts') and len(event.content.parts) > 0:
                    text_parts = [p.text for p in event.content.parts 
                                 if hasattr(p, 'text') and p.text]
                    if text_parts and event.author in [agent_name, "synthesizer"]:
                        print(f"\n💬 Answer:\n")
                        print(text_parts[0])
                        print()
        
        # Show summary if verbose
        if verbose and tool_calls:
            print(f"\n📊 Tool calls made: {', '.join(set(tool_calls))}")
        
        print("="*70 + "\n")
        
    except Exception as e:
        print(f"\n❌ Error running agent: {e}\n")
        import traceback
        traceback.print_exc()


def main():
    """Main CLI entry point."""
    # Parse arguments
    if len(sys.argv) < 3:
        print_usage()
        sys.exit(1)
    
    agent_num = sys.argv[1]
    
    # Check for help
    if agent_num in ["-h", "--help", "help"]:
        print_usage()
        sys.exit(0)
    
    # Check for list
    if agent_num in ["-l", "--list", "list"]:
        print_agents()
        sys.exit(0)
    
    # Get question
    question = " ".join(sys.argv[2:])
    
    # Check for verbose flag
    verbose = "-v" in sys.argv or "--verbose" in sys.argv
    if verbose:
        sys.argv.remove("-v" if "-v" in sys.argv else "--verbose")
    
    # Run agent
    asyncio.run(run_agent(agent_num, question, verbose))


if __name__ == "__main__":
    main()
