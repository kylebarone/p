"""
MCP Tool wrappers for ADK agents.

These wrap the MCP server functions as ADK FunctionTools.
"""

from google.adk.tools import FunctionTool
from mcps.pdf_server import (
    read_pdf,
    search_pdf,
    extract_sections,
    write_note,
    read_note,
    list_notes
)

# PDF operation tools
read_pdf_tool = FunctionTool(read_pdf)
search_pdf_tool = FunctionTool(search_pdf)
extract_sections_tool = FunctionTool(extract_sections)

# Scratchpad tools
write_note_tool = FunctionTool(write_note)
read_note_tool = FunctionTool(read_note)
list_notes_tool = FunctionTool(list_notes)

# Tool groups for easy import
PDF_MCP_TOOLS = [
    read_pdf_tool,
    search_pdf_tool,
    extract_sections_tool
]

SCRATCHPAD_TOOLS = [
    write_note_tool,
    read_note_tool,
    list_notes_tool
]

ALL_MCP_TOOLS = PDF_MCP_TOOLS + SCRATCHPAD_TOOLS
