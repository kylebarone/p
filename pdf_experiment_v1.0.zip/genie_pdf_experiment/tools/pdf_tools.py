"""PDF processing utilities.

NOTE: These are currently MOCK implementations for scaffolding.
Real implementations will use pypdf/pdfplumber for actual PDF processing.
"""

from typing import List


def extract_text_from_pdf(pdf_path: str) -> str:
    """
    Extract all text from a PDF file.
    
    Args:
        pdf_path: Path to the PDF file
        
    Returns:
        Extracted text content
        
    NOTE: MOCK IMPLEMENTATION - Returns sample text
    """
    return f"""
MOCK PDF CONTENT from {pdf_path}

Q3 Financial Report - 2024

Executive Summary:
Our Q3 2024 results show strong growth across all key metrics. Revenue increased
by 12% compared to Q2, reaching $45.3 million. Operating margins improved to 23%,
up from 20% in the previous quarter.

Key Highlights:
- Total Revenue: $45.3M (up 12% QoQ)
- Operating Income: $10.4M (margin: 23%)
- Customer Growth: 15,000 new customers
- Churn Rate: 2.3% (improved from 2.8%)

Product Performance:
Our flagship product saw a 25% increase in adoption, with enterprise customers
showing particular interest. The new features released in August have been well
received, with usage metrics exceeding projections by 40%.

Looking Forward:
We are positioned well for Q4, with a strong pipeline and continued momentum in
our core markets. We expect to achieve full-year revenue of $170M-175M.

[This is mock content for testing agent implementations]
    """.strip()


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
    """
    Split text into overlapping chunks.
    
    Args:
        text: Text to chunk
        chunk_size: Maximum characters per chunk
        overlap: Characters to overlap between chunks
        
    Returns:
        List of text chunks
        
    NOTE: MOCK IMPLEMENTATION - Simple splitting
    """
    # Simple mock implementation
    words = text.split()
    chunks = []
    
    chunk_words = chunk_size // 5  # Rough estimate: ~5 chars per word
    overlap_words = overlap // 5
    
    for i in range(0, len(words), chunk_words - overlap_words):
        chunk = " ".join(words[i:i + chunk_words])
        if chunk:
            chunks.append(chunk)
    
    return chunks if chunks else [text]


def extract_pages(pdf_path: str, pages: List[int]) -> str:
    """
    Extract text from specific pages.
    
    Args:
        pdf_path: Path to the PDF file
        pages: List of page numbers (0-indexed)
        
    Returns:
        Extracted text from specified pages
        
    NOTE: MOCK IMPLEMENTATION
    """
    return f"""
MOCK CONTENT from {pdf_path}, pages {pages}

[Page content would appear here in real implementation]

Sample content for pages {pages}:
- Financial metrics and analysis
- Performance charts
- Strategic initiatives
    """.strip()


def get_pdf_metadata(pdf_path: str) -> dict:
    """
    Get PDF metadata.
    
    Args:
        pdf_path: Path to the PDF file
        
    Returns:
        Dictionary with metadata
        
    NOTE: MOCK IMPLEMENTATION
    """
    return {
        "title": "Q3 Financial Report 2024",
        "author": "Finance Team",
        "pages": 24,
        "creation_date": "2024-10-01",
        "file_size": "2.3 MB"
    }


# Real implementation notes for later:
"""
REAL IMPLEMENTATION using pypdf:

import pypdf

def extract_text_from_pdf(pdf_path: str) -> str:
    with open(pdf_path, 'rb') as file:
        reader = pypdf.PdfReader(file)
        text = []
        for page in reader.pages:
            text.append(page.extract_text())
        return "\\n\\n".join(text)

def extract_pages(pdf_path: str, pages: List[int]) -> str:
    with open(pdf_path, 'rb') as file:
        reader = pypdf.PdfReader(file)
        text = []
        for page_num in pages:
            if 0 <= page_num < len(reader.pages):
                text.append(reader.pages[page_num].extract_text())
        return "\\n\\n".join(text)
"""
