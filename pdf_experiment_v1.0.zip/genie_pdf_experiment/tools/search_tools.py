"""Search tool implementations for PDF content.

NOTE: These are currently MOCK implementations for scaffolding.
Real implementations will use embeddings (sentence-transformers) and BM25.
"""

from typing import List, Dict
from google.adk.tools import FunctionTool


def vector_search(query: str, pdf_name: str = "current", top_k: int = 3) -> List[Dict]:
    """
    Semantic search in PDF using embeddings.
    
    Finds content that is semantically similar to the query, even if
    exact keywords don't match.
    
    Args:
        query: The search query
        pdf_name: Which PDF to search (default: "current")
        top_k: Number of results to return
        
    Returns:
        List of chunks with content, scores, and page numbers
        
    NOTE: MOCK IMPLEMENTATION - Returns sample results
    """
    # Mock results based on query keywords
    query_lower = query.lower()
    
    results = []
    
    if "revenue" in query_lower or "financial" in query_lower or "q3" in query_lower:
        results = [
            {
                "content": "Q3 2024 revenue reached $45.3 million, representing a 12% increase compared to Q2. This growth was driven by strong enterprise adoption and new product features.",
                "score": 0.94,
                "page": 2,
                "source": "Executive Summary"
            },
            {
                "content": "Total Revenue: $45.3M (up 12% QoQ). Operating Income: $10.4M with operating margin of 23%, up from 20% in the previous quarter.",
                "score": 0.89,
                "page": 3,
                "source": "Key Highlights"
            },
            {
                "content": "We expect to achieve full-year revenue of $170M-175M based on current pipeline and Q4 projections.",
                "score": 0.82,
                "page": 12,
                "source": "Forward Outlook"
            }
        ]
    elif "customer" in query_lower or "growth" in query_lower:
        results = [
            {
                "content": "Customer Growth: 15,000 new customers added in Q3. Churn Rate improved to 2.3% from 2.8% in Q2.",
                "score": 0.91,
                "page": 5,
                "source": "Customer Metrics"
            },
            {
                "content": "Enterprise customers showed particular interest, with adoption increasing by 25%. New features released in August exceeded usage projections by 40%.",
                "score": 0.86,
                "page": 8,
                "source": "Product Performance"
            }
        ]
    else:
        results = [
            {
                "content": f"Mock search result for query: '{query}'. This is sample content that would be relevant to your search in a real implementation.",
                "score": 0.75,
                "page": 1,
                "source": "Document"
            }
        ]
    
    return results[:top_k]


def traditional_search(query: str, pdf_name: str = "current", top_k: int = 3) -> List[Dict]:
    """
    Keyword-based search in PDF using BM25.
    
    Finds content that contains the exact keywords from the query.
    Good for specific terms, names, or numerical values.
    
    Args:
        query: The search query
        pdf_name: Which PDF to search
        top_k: Number of results to return
        
    Returns:
        List of chunks with content, BM25 scores, and page numbers
        
    NOTE: MOCK IMPLEMENTATION - Returns sample results
    """
    query_lower = query.lower()
    
    results = []
    
    if "45.3" in query or "$45" in query:
        results = [
            {
                "content": "Total Revenue: $45.3M (up 12% QoQ)",
                "score": 3.45,  # BM25 scores are different scale
                "page": 3,
                "source": "Key Highlights"
            }
        ]
    elif "revenue" in query_lower:
        results = [
            {
                "content": "Our Q3 2024 results show strong growth. Revenue increased by 12% compared to Q2, reaching $45.3 million.",
                "score": 2.87,
                "page": 2,
                "source": "Executive Summary"
            },
            {
                "content": "We expect to achieve full-year revenue of $170M-175M.",
                "score": 2.34,
                "page": 12,
                "source": "Forward Outlook"
            }
        ]
    else:
        results = [
            {
                "content": f"Keyword match for: '{query}'",
                "score": 1.5,
                "page": 1,
                "source": "Document"
            }
        ]
    
    return results[:top_k]


def hybrid_search(query: str, pdf_name: str = "current", top_k: int = 3) -> List[Dict]:
    """
    Combined semantic and keyword search.
    
    Uses both vector and traditional search, then merges and ranks results
    for best coverage.
    
    Args:
        query: The search query
        pdf_name: Which PDF to search
        top_k: Number of results to return
        
    Returns:
        List of chunks with combined ranking
        
    NOTE: MOCK IMPLEMENTATION
    """
    # Get results from both approaches
    vector_results = vector_search(query, pdf_name, top_k)
    traditional_results = traditional_search(query, pdf_name, top_k)
    
    # Simple merge (in real implementation, would use reciprocal rank fusion)
    seen_content = set()
    merged = []
    
    for result in vector_results + traditional_results:
        content = result["content"]
        if content not in seen_content:
            seen_content.add(content)
            merged.append({
                **result,
                "score": result["score"],  # Would normalize and combine scores
                "search_type": "hybrid"
            })
    
    return merged[:top_k]


# Create ADK FunctionTool wrappers
vector_search_tool = FunctionTool(vector_search)
traditional_search_tool = FunctionTool(traditional_search)
hybrid_search_tool = FunctionTool(hybrid_search)


# Real implementation notes for later:
"""
REAL IMPLEMENTATION:

1. Vector Search:
   - Use sentence-transformers to create embeddings
   - Store in FAISS index
   - Query with cosine similarity

from sentence_transformers import SentenceTransformer
import faiss

model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(chunks)
index = faiss.IndexFlatL2(embeddings.shape[1])
index.add(embeddings)

query_embedding = model.encode([query])
distances, indices = index.search(query_embedding, top_k)

2. Traditional Search:
   - Use rank-bm25 library
   
from rank_bm25 import BM25Okapi
tokenized_corpus = [doc.lower().split() for doc in chunks]
bm25 = BM25Okapi(tokenized_corpus)
tokenized_query = query.lower().split()
scores = bm25.get_scores(tokenized_query)

3. Hybrid:
   - Reciprocal Rank Fusion (RRF)
   - Combine rankings from both methods
"""
