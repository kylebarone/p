#!/usr/bin/env python3
"""
Run all agents on the same question and compare results.

Usage:
    python compare_agents.py "<question>"
    
Example:
    python compare_agents.py "What was the Q3 revenue?"
"""

import asyncio
import sys
import time
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from google.adk import Runner
from google.adk.services import InMemorySessionService

# Import all agent creators
from agents.agent_1_gemini_base.agent import create_agent as create_agent_1
from agents.agent_2_gemini_pdf_part.agent import create_agent as create_agent_2
from agents.agent_3_gemini_pdf_processed.agent import create_agent as create_agent_3
from agents.agent_4_gemini_rag_pdf.agent import create_agent as create_agent_4
from agents.agent_5_gemini_agent_search.agent import create_agent as create_agent_5
from agents.agent_6_gemini_pdf_mcp.agent import create_agent as create_agent_6
from agents.agent_7_gemini_pdf_mcp_stateful.agent import create_agent as create_agent_7
from agents.agent_8_gemini_multimodal.agent import create_agent as create_agent_8


AGENTS = [
    ("1", "Gemini Base", "gemini_base", create_agent_1),
    ("2", "Gemini PDF Part", "gemini_pdf_part", create_agent_2),
    ("3", "Gemini PDF Processed", "gemini_pdf_processed", create_agent_3),
    ("4", "Gemini RAG PDF", "gemini_rag_pdf", create_agent_4),
    ("5", "Gemini Agent Search", "gemini_agent_search", create_agent_5),
    ("6", "Gemini PDF MCP", "gemini_pdf_mcp", create_agent_6),
    ("7", "Gemini PDF MCP Stateful", "gemini_pdf_mcp_stateful", create_agent_7),
    ("8", "Gemini Multimodal", "gemini_multimodal", create_agent_8),
]


async def run_single_agent(num, name, agent_name, create_fn, question):
    """Run a single agent and return results."""
    try:
        # Create agent
        if num == "3":
            agent = create_fn(pdf_path="data/pdfs/sample.pdf")
        else:
            agent = create_fn()
        
        # Create runner
        runner = Runner(
            app_name="pdf_qa_compare",
            root_agent=agent,
            session_service=InMemorySessionService()
        )
        
        # Run and collect result
        start_time = time.time()
        answer = None
        event_count = 0
        tool_calls = []
        
        async for event in runner.run_async(
            user_id="compare_user",
            session_id=f"compare_{num}",
            new_message=question
        ):
            event_count += 1
            
            # Collect tool calls
            if hasattr(event.content, 'parts'):
                for part in event.content.parts:
                    if hasattr(part, 'function_call'):
                        tool_calls.append(part.function_call.name)
            
            # Get final answer
            if not event.partial:
                if hasattr(event.content, 'parts') and len(event.content.parts) > 0:
                    text_parts = [p.text for p in event.content.parts 
                                 if hasattr(p, 'text') and p.text]
                    if text_parts and (event.author == agent_name or 
                                      event.author == "synthesizer"):
                        answer = text_parts[0]
        
        duration = time.time() - start_time
        
        return {
            "num": num,
            "name": name,
            "agent_name": agent_name,
            "success": True,
            "answer": answer or "No answer generated",
            "duration": duration,
            "event_count": event_count,
            "tool_calls": tool_calls,
            "tool_count": len(tool_calls)
        }
        
    except Exception as e:
        return {
            "num": num,
            "name": name,
            "agent_name": agent_name,
            "success": False,
            "error": str(e),
            "duration": 0,
            "event_count": 0,
            "tool_calls": [],
            "tool_count": 0
        }


async def compare_all_agents(question: str):
    """Run all agents and compare results."""
    print("\n" + "="*80)
    print("🔬 COMPARING ALL 8 AGENTS")
    print("="*80)
    print(f"\nQuestion: {question}\n")
    print("Running agents...\n")
    
    results = []
    
    # Run all agents
    for num, name, agent_name, create_fn in AGENTS:
        print(f"  {num}. Running {name}...", end=" ", flush=True)
        result = await run_single_agent(num, name, agent_name, create_fn, question)
        results.append(result)
        
        if result["success"]:
            print(f"✅ ({result['duration']:.1f}s)")
        else:
            print(f"❌ Error: {result.get('error', 'Unknown')}")
    
    # Display results
    print("\n" + "="*80)
    print("📊 RESULTS")
    print("="*80 + "\n")
    
    for result in results:
        if not result["success"]:
            continue
            
        print(f"{'─'*80}")
        print(f"Agent {result['num']}: {result['name']}")
        print(f"{'─'*80}")
        print(f"⏱️  Duration: {result['duration']:.2f}s")
        print(f"🔧 Tools Used: {result['tool_count']} ({', '.join(set(result['tool_calls'])) if result['tool_calls'] else 'none'})")
        print(f"📨 Events: {result['event_count']}")
        print(f"\n💬 Answer:\n{result['answer']}\n")
    
    # Summary
    print("="*80)
    print("📈 SUMMARY")
    print("="*80 + "\n")
    
    successful = [r for r in results if r["success"]]
    
    if successful:
        fastest = min(successful, key=lambda x: x["duration"])
        most_tools = max(successful, key=lambda x: x["tool_count"])
        
        print(f"⚡ Fastest: Agent {fastest['num']} ({fastest['name']}) - {fastest['duration']:.2f}s")
        print(f"🔧 Most Tools: Agent {most_tools['num']} ({most_tools['name']}) - {most_tools['tool_count']} tools")
        print(f"✅ Success Rate: {len(successful)}/{len(results)}")
    
    print()


def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print("\n🔬 Compare All Agents\n")
        print("Usage:")
        print('  python compare_agents.py "<question>"')
        print("\nExample:")
        print('  python compare_agents.py "What was the Q3 revenue?"')
        print()
        sys.exit(1)
    
    question = " ".join(sys.argv[1:])
    asyncio.run(compare_all_agents(question))


if __name__ == "__main__":
    main()
