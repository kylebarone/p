"""Shared settings and constants for all agents."""

# Model Configuration
DEFAULT_MODEL = "gemini-2.0-flash-exp"
DEFAULT_TEMPERATURE = 0.7
DEFAULT_MAX_TOKENS = 2048

# PDF Processing
DEFAULT_CHUNK_SIZE = 500
DEFAULT_CHUNK_OVERLAP = 50

# Search Configuration
DEFAULT_TOP_K = 3
DEFAULT_SEARCH_TYPE = "vector"  # "vector", "traditional", "hybrid"

# Common instruction fragments
COMMON_INSTRUCTIONS = {
    "be_concise": "Be concise and direct in your responses.",
    "cite_sources": "Always cite which parts of the document you used to answer.",
    "admit_uncertainty": "If you're not sure, say so. Don't make up information.",
}

def get_instruction_fragment(key: str) -> str:
    """Get a common instruction fragment."""
    return COMMON_INSTRUCTIONS.get(key, "")
