# Setup Guide

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Set Up Google API Key

```bash
export GOOGLE_API_KEY="your-api-key-here"
```

Or create a `.env` file:

```
GOOGLE_API_KEY=your-api-key-here
```

### 3. Add Test PDFs (Optional)

Place your PDF files in `data/pdfs/`:

```bash
cp your-document.pdf data/pdfs/
```

### 4. Test an Agent

```bash
# Run a single agent
python run_agent.py 1 "What is machine learning?"

# See all agents
python run_agent.py --list

# Get help
python run_agent.py --help
```

### 5. Compare All Agents

```bash
python compare_agents.py "What was the Q3 revenue?"
```

## Directory Structure

```
genie_pdf_experiment/
├── agents/              # 8 agent implementations
│   ├── 1_gemini_base/
│   ├── 2_gemini_pdf_part/
│   ├── 3_gemini_pdf_processed/
│   ├── 4_gemini_rag_pdf/
│   ├── 5_gemini_agent_search/
│   ├── 6_gemini_pdf_mcp/
│   ├── 7_gemini_pdf_mcp_stateful/
│   └── 8_gemini_multimodal/
│
├── tools/               # Shared tools
│   ├── pdf_tools.py
│   ├── search_tools.py
│   └── mcp_tools.py
│
├── mcps/                # MCP server
│   └── pdf_server.py
│
├── shared/              # Common settings
│   ├── settings.py
│   └── prompts.py
│
├── data/
│   ├── pdfs/           # Place PDFs here
│   └── sample_questions.txt
│
├── run_agent.py        # Run single agent CLI
├── compare_agents.py   # Compare all agents
└── README.md

```

## Running Agents

### CLI Tools

**run_agent.py** - Run a single agent:
```bash
python run_agent.py 4 "What was the Q3 revenue?"
python run_agent.py 7 "Compare Q3 and Q2 performance"
```

**compare_agents.py** - Run all agents on same question:
```bash
python compare_agents.py "What were the key financial highlights?"
```

### Python API

```python
from agents.agent_4_gemini_rag_pdf.agent import create_agent
from google.adk import Runner
from google.adk.services import InMemorySessionService

agent = create_agent()
runner = Runner(
    app_name="my_app",
    root_agent=agent,
    session_service=InMemorySessionService()
)

async for event in runner.run_async(
    user_id="user1",
    session_id="session1",
    new_message="Your question here"
):
    if not event.partial:
        print(event.content.parts[0].text)
```

### ADK Web Deployment

```bash
# Deploy a single agent
adk web --agent agents/4_gemini_rag_pdf/agent.py

# Or test locally
python agents/4_gemini_rag_pdf/agent.py
```

## Development Status

### ✅ Complete
- All 8 agent implementations
- Mock tools for testing
- CLI tools
- Documentation

### 🚧 Next Steps
- Replace mock tools with real implementations
- Build actual MCP server
- Add real PDF processing
- Implement vector search
- Add more test cases

## Troubleshooting

### Import Errors
Make sure you're running from the project root:
```bash
cd genie_pdf_experiment
python run_agent.py 1 "test"
```

### API Key Issues
Verify your API key is set:
```bash
echo $GOOGLE_API_KEY
```

### Agent Errors
Check individual agent READMEs for specific requirements.

## Next Steps

1. **Test the scaffolding** - Run agents with mock data
2. **Implement real tools** - Replace mocks in `tools/`
3. **Add real PDFs** - Place documents in `data/pdfs/`
4. **Build MCP server** - Create functional MCP implementation
5. **Deploy** - Use ADK Web to make agents available

## Resources

- [Google ADK Documentation](https://github.com/google/adk)
- [ADK Docs](https://google.github.io/adk-docs/)
- Individual agent READMEs in `agents/*/README.md`
